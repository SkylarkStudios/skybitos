import pygame
import syst.col as col
import syst.os as os

audio = [
    'audi/creo-carnivores.ogg', 
    'audi/creo-dimension.ogg',
    'audi/garlagan-00.ogg',
    'audi/geoplex-enduring.ogg',
    'audi/geoplex-singularity.ogg',
    'audi/hinkik-explorers.ogg',
    'audi/hinkik-skystrike.ogg',
         ]
booln = False
num = 0
def playNum():
    pygame.mixer.Sound.play(pygame.mixer.Sound(audio[num]))
def stop():
    pygame.mixer.stop()
def draw():
    # Window
    os.desk.window.draw(100,50,230,150,'Music Player',col.white,'apps_music_player.booln = False')
    order = 0
    # Music Title
    os.desk.screen.blit(os.font_load(20).render(audio[num],True,col.black),(105,80))
    # Back Button
    if not num-1 == -1:    
        os.desk.button('apps_music_player.num -= 1\npygame.time.delay(500)',105 + (order*18),120,18,18,col.gray_sel,col.gray)
        os.desk.icons.arrow_left(106 + (order*18),121,16,16)
        pygame.draw.rect(os.desk.screen,col.black,(105 + (order*18),120,18,18),1)    
    # Play Button
    order += 1
    os.desk.button('apps_music_player.playNum()',105 + (order*18),120,18,18,col.gray_sel,col.gray)
    os.desk.icons.play(106 + (order*18),121,16,16)
    pygame.draw.rect(os.desk.screen,col.black,(105 + (order*18),120,18,18),1)
    # Pause Button
    order += 1
    os.desk.button('pygame.mixer.stop()',105 + (order*18),120,18,18,col.gray_sel,col.gray)
    os.desk.icons.pause(106 + (order*18),121,16,16)
    pygame.draw.rect(os.desk.screen,col.black,(105 + (order*18),120,18,18),1)  
    # Forward Button
    order += 1
    if not num+1 == len(audio): 
        os.desk.button('apps_music_player.num += 1\npygame.time.delay(500)',105 + (order*18),120,18,18,col.gray_sel,col.gray)
        os.desk.icons.arrow_right(106 + (order*18),121,16,16)
        pygame.draw.rect(os.desk.screen,col.black,(105 + (order*18),120,18,18),1)    
    
    
