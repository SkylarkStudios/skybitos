from array import *
import pygame
import syst.os as os
import syst.col as col
import apps.music_player as apps_music_player
# import launcher

pygame.init()
pygame.display.set_caption("Sky9 Launcher")
fps = 60
pygame.font.init()
font = pygame.font.Font('reso/font.ttf',30)
def font_load(size):
    return pygame.font.Font('reso/font.ttf',size)

os.mode = 'desk'
if os.debug == True:
    os.desk.screen = pygame.display.set_mode((480,360))
elif os.debug == False:
    os.desk.screen = pygame.display.set_mode((480,360), pygame.FULLSCREEN)
pygame.display.set_caption('Sky9')
# os.desk.start()
while True:
    if os.mode == 'launcher':
        # Timer
        pygame.time.delay(round(1000 / fps))
        # Screen Update
        os.launcher.draw()
        os.launcher.update()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        pygame.display.update()
    
    if os.mode == 'desk':
        # Timer
        pygame.time.delay(round(1000 / fps))
        # Screen Update
        os.desk.draw()
        keys = pygame.key.get_pressed()
        # System Apps Check
        if os.desk.info.booln == True:
            os.desk.info.draw()
        if os.desk.opts.booln == True:
            os.desk.opts.draw()
        if os.desk.logs.booln == True:
            os.desk.logs.draw()
        if keys[pygame.K_q]:
            pygame.quit()
            quit()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        pygame.display.update()
        


