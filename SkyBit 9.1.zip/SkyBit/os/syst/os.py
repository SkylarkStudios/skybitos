import pygame
import syst.col as col
import apps.music_player as apps_music_player
pygame.init()
mode = 'launcher'
debug = True
startup = pygame.mixer.Sound('reso/startup.ogg')
pygame.font.init()
def font_load(size):
    return pygame.font.Font('reso/font.ttf',size)
bg = ['reso/bg_1.png','reso/bg_2.png']
class launcher:
    # The Launcher Simulator is currently broken right now so it will automatically go to the desktop
    screen = pygame.display.set_mode((600,200))
    pygame.display.set_icon(pygame.image.load('reso/logo_blue_120.png'))
    loader_var = 100
    timer_var = 0
    loader_timer = 0
    loader_textNum = 0
    loader_text = [
        'Downloading Data',
        'Importing /os/pygame/',
        'Importing /os/resources/',
        'Importing /os/SkyBit.py',
        'Creating Desktop',
        'Initializing SkyOS9',
        'Starting SkyBit',
        '/end/',
        ]
    def draw():
        launcher.screen.fill(col.white)
        pygame.draw.rect(launcher.screen,col.green,(100,75,400,50))
        pygame.draw.rect(launcher.screen,col.green_light,(launcher.loader_var,75,50,50))
        launcher.screen.blit(font_load(16)(launcher.loader_text[launcher.loader_textNum], True, col.black), (100,125))
    def update():
        # Loader Movement
        if launcher.loader_var >= 450:
            launcher.loader_var = 100
        else:
            launcher.loader_var += 2
        
        # Downloader Info
        launcher.timer_var += 0.01
        launcher.loader_textNum = round(launcher.timer_var)
        if launcher.loader_text[launcher.loader_textNum] == '/end/':
            mode = 'desk'
            desk.screen = pygame.display.set_mode((480,360)) # , pygame.FULLSCREEN
            pygame.display.set_caption('Sky9')
class desk:
    screen = 0
    class icons:
        def arrow_left(posX,posY,sizeX,sizeY):
            pygame.draw.line(desk.screen,col.black,(posX, posY + (sizeY / 2)),(posX + sizeX, posY + (sizeY / 2)))
            pygame.draw.line(desk.screen,col.black,(posX + (sizeX / 2), posY),(posX, posY + (sizeY / 2)))
            pygame.draw.line(desk.screen,col.black,(posX + (sizeX / 2), posY + sizeY),(posX, posY + (sizeY / 2)))            
        def arrow_right(posX,posY,sizeX,sizeY):
            pygame.draw.line(desk.screen,col.black,(posX, posY + (sizeY / 2)),(posX + sizeX, posY + (sizeY / 2)))
            pygame.draw.line(desk.screen,col.black,(posX + (sizeX / 2), posY),(posX + sizeX, posY + (sizeY / 2)))
            pygame.draw.line(desk.screen,col.black,(posX + (sizeX / 2), posY + sizeY),(posX + sizeX, posY + (sizeY / 2)))
        def play(posX,posY,sizeX,sizeY):
            pygame.draw.polygon(desk.screen,col.black,[(posX,posY),(posX + sizeX, posY + (sizeY / 2)),(posX,posY+sizeY)],1)
        def pause(posX,posY,sizeX,sizeY):
            pygame.draw.line(desk.screen,col.black,(posX + (sizeX / 3),(posY)),(posX + (sizeX / 3), posY + sizeY))
            pygame.draw.line(desk.screen,col.black,(posX + 2*(sizeX / 3),(posY)),(posX + 2*(sizeX / 3), posY + sizeY))
    def button(action,posX,posY,sizeX,sizeY,hover,noHover):
        mouseX, mouseY = pygame.mouse.get_pos()
        if mouseX > posX and mouseY > posY and mouseX < posX + sizeX and mouseY < posY + sizeY:
            if not (hover == 0 and noHover == 0):
                pygame.draw.rect(desk.screen,hover,(posX,posY,sizeX,sizeY))
            if pygame.mouse.get_pressed()[0]:
                exec(action)
                pygame.time.delay(100)
        else:
            if not (hover == 0 and noHover == 0):
                pygame.draw.rect(desk.screen,noHover,(posX,posY,sizeX,sizeY))
    
        
        
    class startmenu:
        booln = False
        def draw():
            sizeX = 100
            # Background
            pygame.draw.rect(desk.screen,col.white,(0,230,sizeX,330-230))
            pygame.draw.rect(desk.screen,col.black,(0,230,sizeX,330-230),1)
            # Apps Button
            order = 0
            desk.button('desk.appsmenu.booln = True',0,230+(order*18),sizeX,18,col.white_sel,col.white)
            pygame.draw.rect(desk.screen,col.black,(0,230+(order*18),sizeX,18),1)
            desk.screen.blit(font_load(16).render('Applications', True, col.black), (5,230+(order*18)))            
            # Info Button
            order += 1
            desk.button('desk.info.booln = True',0,230+(order*18),sizeX,18,col.white_sel,col.white)
            pygame.draw.rect(desk.screen,col.black,(0,230+(order*18),sizeX,18),1)
            desk.screen.blit(font_load(16).render('Information', True, col.black), (5,230+(order*18)))
            # Opts Button
            order += 1
            desk.button('desk.opts.booln = True',0,230+(order*18),sizeX,18,col.white_sel,col.white)
            pygame.draw.rect(desk.screen,col.black,(0,230+(order*18),sizeX,18),1)
            desk.screen.blit(font_load(16).render('Options', True, col.black), (5,230 +(order*18)))
            # Logs Button
            order += 1
            desk.button('desk.logs.booln = True',0,230+(order*18),sizeX,18,col.white_sel,col.white)
            pygame.draw.rect(desk.screen,col.black,(0,230+(order*18),sizeX,18),1)            
            desk.screen.blit(font_load(16).render('Update Logs', True, col.black), (5,230 +(order*18)))
            # Shut Down Button
            order += 1
            desk.button('pygame.quit()\nquit()',0,230+(order*18),sizeX,18,col.red_sel,col.red)
            pygame.draw.rect(desk.screen,col.black,(0,230+(order*18),sizeX,18),1)
            desk.screen.blit(font_load(16).render('Shut Down', True, col.black), (5,230+(order*18)))
    class appsmenu:
        booln = False
        def draw():
            sizeX = 100
            # Background
            pygame.draw.rect(desk.screen,col.white,(100,230,sizeX,330-230))
            pygame.draw.rect(desk.screen,col.black,(100,230,sizeX,330-230),1)
            order = 0
            # Music Player Button
            desk.button('apps_music_player.booln = True',100,230+(order*18),sizeX,18,col.white_sel,col.white)
            pygame.draw.rect(desk.screen,col.black,(100,230+(order*18),sizeX,18),1)
            desk.screen.blit(font_load(16).render('Music Player', True, col.black), (105,230+(order*18)))
            # Back Button
            order += 1
            desk.button('desk.appsmenu.booln = False',100,230+(order*18),sizeX,18,col.red_sel,col.red)
            pygame.draw.rect(desk.screen,col.black,(100,230+(order*18),sizeX,18),1)
            desk.screen.blit(font_load(16).render('Back', True, col.black), (105,230+(order*18)))            
            
            
            
    class info:
        text = ['Version Sky9.01',
                'Created by Samuel (Skyan) Skylark',]
            
        booln = False
        def draw():
            desk.window.draw(100,100,215,100,'Info',col.white,'desk.info.booln = False')
            desk.screen.blit(font_load(16).render(desk.info.text[0],True,col.black),(105,120))
            desk.screen.blit(font_load(16).render(desk.info.text[1],True,col.black),(105,120 + 18))
    class logs:
        text = ['Update 9.01:',
                '-added information tab',
                '-added options tab',
                '-added music player',
                '-added update logs',]
        booln = False
        def draw():
            desk.window.draw(100,100,230,150,'Update Logs',col.white,'desk.logs.booln = False')
            i = 0
            while i < len(desk.logs.text):
                desk.screen.blit(font_load(16).render(desk.logs.text[i],True,col.black),(105,120 + (18 * i)))
                i += 1
    class opts:
        bg = 0
        booln = False
        def draw():
            # Window
            desk.window.draw(100,100,215,100,'Options',col.white,'desk.opts.booln = False')
            # Background Text
            desk.screen.blit(font_load(16).render('Background',True,col.black),(105,120))
            # Background Switch Left
            if not (desk.opts.bg == 0):
                desk.button('desk.opts.bg -= 1',180,120,20,20,col.gray_sel,col.gray)
                desk.icons.arrow_left(180,120,20,20)
                pygame.draw.rect(desk.screen,col.black,(180,120,20,20),1)
            # Background Switch Right
            if not (desk.opts.bg+1 == len(bg)):
                desk.button('desk.opts.bg += 1',205,120,20,20,col.gray_sel,col.gray)
                desk.icons.arrow_right(205,120,20,20)
                pygame.draw.rect(desk.screen,col.black,(205,120,20,20),1)
    class window:
        def draw(posX,posY,sizeX,sizeY,title,bg,exit):
            # Background
            pygame.draw.rect(desk.screen,bg,(posX,posY,sizeX,sizeY))
            pygame.draw.rect(desk.screen,col.black,(posX,posY,sizeX,sizeY),1)
            # Header
            pygame.draw.rect(desk.screen,col.gray,(posX,posY,sizeX,18))
            pygame.draw.rect(desk.screen,col.black,(posX,posY,sizeX,18),1)
            # Exit Icon
            exit_coords = [
                (posX + sizeX - 18, posY),
                (posX + sizeX, posY),
                (posX + sizeX, posY + 18),
                (posX + sizeX - 18, posY + 18),
                ]
            desk.button(exit,posX + sizeX - 18,posY,18,18, col.red_sel, col.red)
            pygame.draw.line(desk.screen,col.white,exit_coords[0],exit_coords[2],1)
            pygame.draw.line(desk.screen,col.white,exit_coords[1],exit_coords[3],1)
            pygame.draw.rect(desk.screen,col.black,(posX + sizeX - 18,posY,18,18),1)
            # Header Title
            desk.screen.blit(font_load(16).render(title, True, col.black), (posX+2,posY+2))
            
    
    def start():
        pygame.mixer.stop()
        pygame.mixer.Sound.play(os.startup)
        pygame.time.delay(5000)
        pygame.mixer.stop()

                                                   
    def draw():
        # Background
        desk.screen.fill(col.white)
        desk.screen.blit(pygame.image.load(bg[desk.opts.bg]),(0,0))
        # Footer
        pygame.draw.rect(desk.screen,col.blue,(0,330,480,360))
        desk.screen.blit(pygame.image.load('reso/logo_blue.png'),(5,333))
        # Start Menu
        if desk.startmenu.booln == False:
            desk.button('desk.startmenu.booln = True',5,333,24,24,0,0)
        elif desk.startmenu.booln == True:
            desk.button('desk.startmenu.booln = False',5,333,24,24,0,0)
            desk.startmenu.draw()
        if desk.appsmenu.booln == True:
            desk.appsmenu.draw()
        if apps_music_player.booln == True:
            apps_music_player.draw()



        # os.desk.window.draw(0,0,200,200,'Test Window',col.white)

